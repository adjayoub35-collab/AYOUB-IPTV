package com.ayoub.iptv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private EditText m3uUrl, directUrl;
    private TextView status;
    private LinearLayout list;

    static class Channel {
        String name, url, group;
        Channel(String n, String u, String g) { name=n; url=u; group=g; }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        m3uUrl = findViewById(R.id.m3uUrl);
        directUrl = findViewById(R.id.directUrl);
        status = findViewById(R.id.status);
        list = findViewById(R.id.list);
        findViewById(R.id.loadButton).setOnClickListener(v -> loadM3u());
        findViewById(R.id.playDirect).setOnClickListener(v -> {
            String u = directUrl.getText().toString().trim();
            if (u.isEmpty()) { toast("أدخل رابط البث أولاً"); return; }
            play("البث المباشر", u);
        });
    }

    private void loadM3u() {
        final String u = m3uUrl.getText().toString().trim();
        if (u.isEmpty()) { toast("أدخل رابط M3U"); return; }
        status.setText("جارٍ تحميل القائمة...");
        new Thread(() -> {
            List<Channel> result = new ArrayList<>();
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(u).openConnection();
                c.setConnectTimeout(15000); c.setReadTimeout(20000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                String line, name="Channel", group="Live TV";
                while ((line=r.readLine()) != null) {
                    line=line.trim();
                    if (line.startsWith("#EXTINF")) {
                        int comma=line.indexOf(',');
                        name = comma >= 0 ? line.substring(comma+1).trim() : "Channel";
                        int g=line.indexOf("group-title=\"");
                        if (g >= 0) { int s=g+13, e=line.indexOf('"',s); if(e>s) group=line.substring(s,e); }
                    } else if ((line.startsWith("http://") || line.startsWith("https://")) && !line.startsWith("#")) {
                        result.add(new Channel(name,line,group)); name="Channel"; group="Live TV";
                    }
                }
                r.close(); c.disconnect();
                runOnUiThread(() -> showChannels(result));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("تعذر تحميل القائمة: " + e.getMessage()));
            }
        }).start();
    }

    private void showChannels(List<Channel> channels) {
        list.removeAllViews();
        status.setText("تم العثور على " + channels.size() + " قناة");
        for (Channel ch: channels) {
            Button v = new Button(this);
            v.setText(ch.name + "\n" + ch.group);
            v.setTextColor(Color.WHITE);
            v.setAllCaps(false);
            v.setTextSize(18);
            v.setFocusable(true);
            v.setClickable(true);
            v.setOnClickListener(x -> play(ch.name, ch.url));
            list.addView(v, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private void play(String name, String url) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("name", name); i.putExtra("url", url); startActivity(i);
    }

    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
