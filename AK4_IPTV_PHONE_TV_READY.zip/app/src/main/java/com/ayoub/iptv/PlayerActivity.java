package com.ayoub.iptv;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;

public class PlayerActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_player);
        VideoView video = findViewById(R.id.video);
        Button back = findViewById(R.id.back);
        back.setOnClickListener(v -> finish());
        String url = getIntent().getStringExtra("url");
        if (url == null || url.isEmpty()) { finish(); return; }
        video.setVideoURI(Uri.parse(url));
        video.setOnPreparedListener(mp -> { mp.setLooping(false); video.start(); });
        video.setOnErrorListener((mp, what, extra) -> {
            Toast.makeText(this, "تعذر تشغيل هذا البث. قد يحتاج إلى مشغل خارجي مثل VLC.", Toast.LENGTH_LONG).show();
            return false;
        });
    }
}
