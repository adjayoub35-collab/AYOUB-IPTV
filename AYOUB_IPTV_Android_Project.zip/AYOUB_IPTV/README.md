# AYOUB IPTV — Android starter project

مشروع Android باسم **AYOUB IPTV** مع شعار A متحرك بصريًا، ودعم:
- Xtream Codes (بناء روابط البث القياسية)
- M3U URL واستيراد قوائم M3U
- Live TV / Movies / Series
- مشغل Media3/ExoPlayer
- واجهة داكنة وشعار AYOUB

## المتطلبات
- Android Studio حديث
- JDK 17
- اتصال بالإنترنت عند أول Gradle Sync

## التشغيل
1. افتح مجلد `AYOUB_IPTV` في Android Studio.
2. انتظر Gradle Sync.
3. شغّل التطبيق على هاتف Android أو Emulator.
4. اضغط "إضافة مصدر IPTV".

## ملاحظة مهمة
استخدم التطبيق فقط مع القنوات والقوائم التي تملكها أو لديك ترخيص لبثها. المشروع لا يتضمن أي قنوات أو اشتراكات مدفوعة.

## تطويرات لاحقة مقترحة
- صفحة Dashboard حقيقية مع تبويبات Live / Movies / Series.
- جلب بيانات Xtream API وعرض التصنيفات والصور وEPG.
- Stalker/MAG API مع بوابة مرخّصة.
- حفظ الحسابات محليًا بصورة آمنة.
- Favorites وSearch وParental PIN.
- شاشة Splash متحركة منفصلة وشعار launcher بأحجام متعددة.
