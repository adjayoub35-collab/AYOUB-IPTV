package com.ayoub.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class Channel(val name: String, val url: String, val group: String = "Live TV")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AyoubApp() }
    }
}

@Composable
fun AyoubApp() {
    var screen by remember { mutableStateOf("home") }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var selected by remember { mutableStateOf<Channel?>(null) }
    var showLogin by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF05070B),
            surface = Color(0xFF0B1018),
            primary = Color(0xFF00C8FF)
        )
    ) {
        when {
            selected != null -> PlayerScreen(selected!!) { selected = null }
            showLogin -> LoginScreen(
                onBack = { showLogin = false },
                onXtream = { host, user, pass ->
                    showLogin = false
                    channels = emptyList()
                    // The app builds standard Xtream playlist URLs.
                    // Only use servers/content you own or are licensed to access.
                    val clean = host.trimEnd('/')
                    val urls = listOf(
                        "$clean/live/$user/$pass/",
                        "$clean/movie/$user/$pass/",
                        "$clean/series/$user/$pass/"
                    )
                    channels = urls.mapIndexed { i, u ->
                        Channel("Xtream source ${i+1}", u, when(i) {
                            0 -> "Live TV"; 1 -> "Movies"; else -> "Series"
                        })
                    }
                },
                onM3u = { url ->
                    showLogin = false
                    // M3U import is performed asynchronously.
                    LaunchedEffectKey(url) { result ->
                        channels = result
                    }
                }
            )
            else -> HomeScreen(
                channels = channels,
                onAdd = { showLogin = true },
                onPlay = { selected = it }
            )
        }
    }
}

@Composable
private fun LaunchedEffectKey(url: String, onResult: (List<Channel>) -> Unit) {
    LaunchedEffect(url) {
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val client = OkHttpClient()
                val req = Request.Builder().url(url).build()
                val body = client.newCall(req).execute().body?.string().orEmpty()
                parseM3u(body)
            }.getOrDefault(emptyList())
        }
        onResult(result)
    }
}

fun parseM3u(text: String): List<Channel> {
    val lines = text.lines()
    val out = mutableListOf<Channel>()
    var pendingName = "Channel"
    var pendingGroup = "Live TV"
    for (line in lines) {
        val s = line.trim()
        if (s.startsWith("#EXTINF")) {
            pendingName = s.substringAfterLast(",").ifBlank { "Channel" }
            pendingGroup = Regex("""group-title="([^"]*)"""")
                .find(s)?.groupValues?.getOrNull(1) ?: "Live TV"
        } else if (s.isNotBlank() && !s.startsWith("#") && (s.startsWith("http://") || s.startsWith("https://"))) {
            out += Channel(pendingName, s, pendingGroup)
            pendingName = "Channel"
        }
    }
    return out
}

@Composable
fun HomeScreen(channels: List<Channel>, onAdd: () -> Unit, onPlay: (Channel) -> Unit) {
    val infinite = rememberInfiniteTransition(label = "a")
    val scale by infinite.animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "logoScale"
    )

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF05070B)).padding(16.dp)
    ) {
        Image(
            painter = painterResource(com.ayoub.iptv.R.drawable.ayoub_logo),
            contentDescription = "AYOUB IPTV",
            modifier = Modifier.fillMaxWidth().height(220.dp).scale(scale),
            contentScale = ContentScale.Fit
        )

        Text("AYOUB IPTV", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Live TV • Movies • Series", color = Color(0xFF00C8FF), fontSize = 14.sp)

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) { Text("إضافة مصدر IPTV") }

        Spacer(Modifier.height(14.dp))

        if (channels.isEmpty()) {
            Text(
                "لم تتم إضافة قائمة بعد.\nيمكنك إضافة رابط M3U أو بيانات Xtream.",
                color = Color.LightGray,
                modifier = Modifier.padding(8.dp)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(channels) { ch ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onPlay(ch) },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF101722))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(ch.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(ch.group, color = Color(0xFF00C8FF), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    onBack: () -> Unit,
    onXtream: (String, String, String) -> Unit,
    onM3u: (String) -> Unit
) {
    var host by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var m3u by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF05070B)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.ayoub_logo),
            contentDescription = null,
            modifier = Modifier.height(150.dp)
        )
        Text("إضافة اشتراك", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(host, { host = it }, label = { Text("Server URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { onXtream(host, user, pass) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("دخول Xtream Codes") }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            m3u, { m3u = it },
            label = { Text("M3U URL") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { onM3u(m3u) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("استيراد M3U") }

        TextButton(onClick = onBack) { Text("رجوع") }
    }
}

@Composable
fun PlayerScreen(channel: Channel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← رجوع") }
            Text(channel.name, color = Color.White, modifier = Modifier.padding(start = 8.dp))
        }
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player } },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}
